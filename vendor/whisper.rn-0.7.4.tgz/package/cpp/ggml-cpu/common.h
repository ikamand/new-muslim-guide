#pragma once

#include "ggml.h"
#include "traits.h"
#include "ggml-cpu-impl.h"
#include "ggml-impl.h"
#include "simd-mappings.h"

#define WSP_GGML_FA_TILE_Q  64
#define WSP_GGML_FA_TILE_KV 64

#ifdef __cplusplus

#include <utility>

// convenience functions/macros for use in template calls
// note: these won't be required after the 'traits' lookup table is used.
static inline wsp_ggml_fp16_t f32_to_f16(float x) {
    return WSP_GGML_CPU_FP32_TO_FP16(x);
}

static inline float f16_to_f32(wsp_ggml_fp16_t x) {
    return WSP_GGML_CPU_FP16_TO_FP32(x);
}

static inline wsp_ggml_bf16_t f32_to_bf16(float x) {
    return WSP_GGML_FP32_TO_BF16(x);
}

static inline float bf16_to_f32(wsp_ggml_bf16_t x) {
    return WSP_GGML_BF16_TO_FP32(x);
}

static inline float i32_to_f32(int32_t x) {
    return x;
}

static inline int32_t f32_to_i32(float x) {
    return x;
}

static inline float f32_to_f32(float x) {
    return x;
}

// TODO - merge this into the traits table, after using row-based conversions
template <class T>
struct type_conversion_table;

template <>
struct type_conversion_table<wsp_ggml_fp16_t> {
    static constexpr float (*to_f32)(wsp_ggml_fp16_t) = f16_to_f32;
    static constexpr wsp_ggml_fp16_t (*from_f32)(float) = f32_to_f16;
};

template <>
struct type_conversion_table<float> {
    static constexpr float (*to_f32)(float) = f32_to_f32;
    static constexpr float (*from_f32)(float) = f32_to_f32;
};

template <>
struct type_conversion_table<wsp_ggml_bf16_t> {
    static constexpr float (*to_f32)(wsp_ggml_bf16_t) = bf16_to_f32;
    static constexpr wsp_ggml_bf16_t (*from_f32)(float) = f32_to_bf16;
};

template <>
struct type_conversion_table<int32_t> {
    static constexpr float (*to_f32)(int32_t) = i32_to_f32;
    static constexpr int32_t (*from_f32)(float) = f32_to_i32;
};

static std::pair<int64_t, int64_t> get_thread_range(const struct wsp_ggml_compute_params * params, const struct wsp_ggml_tensor * src0) {
    const int64_t ith = params->ith;
    const int64_t nth = params->nth;

    const int64_t nr  = wsp_ggml_nrows(src0);

    // rows per thread
    const int64_t dr = (nr + nth - 1)/nth;

    // row range for this thread
    const int64_t ir0 = dr*ith;
    const int64_t ir1 = MIN(ir0 + dr, nr);

    return {ir0, ir1};
}

struct wsp_ggml_fa_tile_config {
    static constexpr size_t Q  = WSP_GGML_FA_TILE_Q;
    static constexpr size_t KV = WSP_GGML_FA_TILE_KV;
};

#endif
